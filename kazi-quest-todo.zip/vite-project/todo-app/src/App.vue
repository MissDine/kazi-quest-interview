<template>
  <div class="h-full w-full">
    <todo-list></todo-list>
  </div>
</template>
<script setup lang="ts">
import TodoList from './components/TodoList.vue';
</script>
<style scoped>
</style>
