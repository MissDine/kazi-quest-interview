export interface Todo {
    id: string
    todo: string
    description: string
    active: boolean
    complete: boolean
}

